package com.kh.controller;

import java.util.ArrayList;

import com.kh.model.dao.MemberDao;
import com.kh.model.vo.Member;
import com.kh.view.MemberView;

/*
 * * Controller 코드 플로우
 * 1) 요청 시 전달받은 값들을 하나의 VO 객체로 가공
 * 2) DAO 로 전달값을 넘기면서 메소드 호출 후 결과 받기
 * 3) 결과에 따른 응답화면 지정
 * 
 */
public class MemberController {
	
	/**
	 * 회원 추가 요청 시 실행할 메소드
	 * @param userId
	 * @param userPwd
	 * @param userName
	 * @param gender
	 * @param age
	 * @param email
	 * @param phone
	 * @param address
	 * @param hobby => 사용자가 회원 추가요청시 입력했던 값들
	 */
	public void insertMember(String userId, String userPwd,
							String userName,String gender,
							int age,
							String email, String phone,
							String address, String hobby) {
		
		// 1) 요청시 전달값들을 VO 객체로 가공
		Member m = new Member(userId, userPwd, userName,
							  gender,age,email,phone,address,hobby);
		
		// 2) DAO 로 전달값을 넘기면서 메소드 호출 후 결과 받기
		int result = new MemberDao().insertMember(m);
		
		// 3) 결과에 따른 응답화면 지정
		if(result > 0) { //성공했을 경우
			
			new MemberView().displaySuccess("회원 추가 성공");
			
		}else { // 실패했을 경우
			
			new MemberView().displayFail("회원 추가 실패");
			
		}
		
		
	} // insertMember 메소드 끝
	/**
	 * 회원 전체 조회 요청 처리용 메소드
	 */
	public void selectAll() {
		// 1) 요청 시 전달값들을 하나의 VO 객체에 담기
		// > 요청 시 전달값이 없으므로 패스
		
		// 2) DAO 로 전달값을 넘기면서 메소드 호출 후 결과 받기
		// > 전체 조회 기능이기 때문에 "여러행 조회" 임!!
		ArrayList<Member> list = new MemberDao().selectAll();
		if(list.isEmpty()) { // 조회 결과가 없을 경우
			
			new MemberView().displayNodata("전체 조회 결과가 없습니다.");
			
		} else { // 조회 결과가 있을 경우
			
			new MemberView().dsiplayList(list);
			
			
		} 
		
		
		
		
	}
	/**
	 * 아이디로 회원 검색 요청을 처리해주는 메소드
	 * @param userId => 검색할 회원의 아이디
	 */
	public void selectByUserId(String userId) {
		
		// 1) 요청 시 전달값들을 하나의 VO 타입으로 가공
		// > 전달값이 한개만 있으므로 패스
		
		// 2) DAO 로 전달값을  넘기면서 메소드 호출후 결과 받기
		// > 아이디로 검색은 Unique 제약조건에 의해 "단일행 조회"임!!
		Member m = new MemberDao().selectByUserId(userId);
		// 3) 결과에 따른 응답화면 지정
		if(m == null) { // 조회결과가 없을 경우
			
			new MemberView().displayNodata(userId + "에 해당하는 검색 결과가 없습니다.");
			
		}else { // 조회결과가 있을 경우
			new MemberView().displayOne(m);
		}
		
	} // selectByUserId 메소드 끝
	
	/**
	 * 사용자의 이름 키워드 검색 요청을 받아줄 메소드
	 * @param keyword => 이름 검색용 검색어
	 */
	public void selectByUserName(String keyword){
		
		// 1) 요청 시 전달값들을 하나의 VO 타입으로 가공하기
		// > 요청 시 전달값이 단 한개이기 때문에
		
		// 2) DAO 로 전달값을 넘기면서 호출 후 결과 받기
		// > 이름 키워드 검색은 한번에 여러명의 데이터가 조회될수 있으므로
		// "여러행 조회" 임!!
		ArrayList<Member> list = new MemberDao().selectByUserName(keyword);
		
		// 3) 결과에 따른 응답화면 지정
		if(list.isEmpty()) { // 조회 결과가 없을경우
		
			new MemberView().displayNodata(keyword + "에 해당하는 검색 결과가 없습니다.");
			
		}else { // 조회 결과가 있을 경우
			
			new MemberView().dsiplayList(list);
			
		}
		
	}
	/**
	 * 사용자의 회원 정보 변경 요청을 처리해주는 메소드
	 * @param userId => 변경하고자 하는 회원의 아이디
	 * @param newPwd
	 * @param newEmail
	 * @param newPhone
	 * @param newAddress
	 */
	public void updateMember(String userId, String newPwd,
			String newEmail,String newPhone,String newAddress) {
		
		// 1) 요청 시 전달값들을 하나의 VO 로 가공하기
		Member m = new Member();
		m.setUserId(userId);
		m.setUserPwd(newPwd);
		m.setEmail(newEmail);
		m.setPhone(newPhone);
		m.setAddress(newAddress);
		
		// 2) DAO 로 전달값을 넘기면서 호출 후 결과 받기
		
		int result = new MemberDao().updateMember(m);
		
		//3 ) 결과에 따른 응답화면 지정
		
		if(result > 0) { // 성공
			new MemberView().displaySuccess("회원 정보 변경 성공");
		}else { // 실패
			new MemberView().displayFail("회원 정보 변경 실패");
		}
	
	} // updateMember 메소드 끝
	/**
	 * 회원 탈퇴 요청을 받아 처리해주는 메소드
	 * @param userId => 탈퇴할 회원의 아이디
	 */
	public void deleteMember(String userId) {
		
		// 1) 요청 시 전달값들을 하나의 VO 객체로 가공하기
		// > 전달값이 한 개 이므로 패스
		
		// 2) DAO로 전달값을 넘기면서 호출 후 결과 받기
		
		int result = new MemberDao().deleteMember(userId);
		
		// 3) 결과값에 따른 응답 화면 지정
		if(result >0) {// 성공
			
			new MemberView().displaySuccess("회원 탈퇴 성공");
			
			
		}else { //실패
			
			new MemberView().displayFail("회원 탈퇴 실패");
		}
		
	}// deleteMember 메소드 끝
	
	
	
	
	
	
	
	
}
