package com.kh.run;

import com.kh.view.MemberView;

public class Run {

	public static void main(String[] args) {
		 new MemberView().mainMenu(); 
		 // 한번 호출하고 말거라서 예전처럼 변수 지정 안해도 됨
		
		 
	}

}
