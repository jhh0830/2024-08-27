package com.kh.view;

import java.util.ArrayList;
import java.util.Scanner;

import com.kh.controller.MemberController;
import com.kh.model.vo.Member;

public class MemberView {
		
	// Scanner 객체는 전역변수로 빼기
	private Scanner sc = new Scanner(System.in);
	
	// MemberController 객체 또한 전역변수로 빼기
	private MemberController mc =  new MemberController();
	
/**
 * 사용자가 보게 될 첫 화면 (메인화면)
 */
	public void mainMenu() {
		
		while(true) {
			
			System.out.println("***** 회원 관리 프로그램 *****");
			System.out.println("1. 회원 추가");
			System.out.println("2. 회원 전체 조회");
			System.out.println("3. 회원 아이디로 검색");
			System.out.println("4. 회원 이름 키워드 검색");
			System.out.println("5. 회원 정보 변경");
			System.out.println("6. 회원 탈퇴");
			System.out.println("0. 프로그램 종료");
			
			System.out.println("------------------------------");
			
			System.out.print("이용할 메뉴 선택 : ");
			int menu = sc.nextInt();
			sc.nextLine();
			
			switch(menu) {
			case 1 : 
				insertMember();
				break;
			case 2 :
				selectAll();
				break;
			case 3 :
				selectByUserId();
				break;
			case 4 :
				selectByUserName();
				break;
			case 5 :
				updateMember();
				break;
			case 6 :
				deleteMember();
			
				break;
			case 7 : break;
			case 0 :
				System.out.println("프로그램을 종료합니다");
				return;
			default :
				System.out.println("번호를 잘못입력하셧습니다 다시 입력해 주세요");
				
			}
			
			
		}
		
		
	} // mainMenu 메소드 끝
	
	/**
	 * 회원 추가용 화면
	 */
	public void  insertMember() {
		
		System.out.println("--- 회원 추가 ---");
		
		// 회원 추가 요청 시 필요한 데이터 
		// > 아이디, 비번, 이름, 성별, 나이, 이메일, 전화번호, 주소 , 취미
		
		System.out.print("* 아이디 : ");
		String userId = sc.nextLine();
		
		System.out.print("* 비밀번호 : ");
		String userPwd = sc.nextLine();
		
		System.out.print("* 이름 : ");
		String userName= sc.nextLine();
		
		System.out.print(" 성별(M/F) : ");
		String gender = sc.nextLine().toUpperCase();
		
		System.out.print(" 나이 : ");
		int age = sc.nextInt();
		sc.nextLine();
		
		System.out.print(" 이메일 : ");
		String email = sc.nextLine();
		
		System.out.print(" 전화번호(숫자만) : ");
		String phone = sc.nextLine();
		
		System.out.print(" 주소 : ");
		String address = sc.nextLine();
		
		System.out.print(" 취미 : ");
		String hobby = sc.nextLine();
		
		// Controller 의 어떤 메소드를 호출하면서 회원 추가 요청
		// (위에서 입력받은 값들을 전달하면서)
		mc.insertMember(userId,userPwd,userName,gender,age,
				email,phone,address,hobby);
		
		
	} // insertMember 메소드 끝
	
	/**
	 * 회원 전체 조회용 화면
	 */
	public void selectAll() {
		System.out.println("--- 회원 전체 조회 ---");
		
		// Controller 로 회원 전체 조회 요청
		mc.selectAll();
	} // selectAll 메소드 끝
	

	public void selectByUserId() {
		System.out.println("--- 회원 아이디 검색 ---");
		System.out.print("검색할 회원의 아이디 : ");
		String userId = sc.nextLine();
		
		// Controller 로 userId를 넘기면서 아이디 검색 요청 보내기
		mc.selectByUserId(userId);
	}
	/**
	 *  회원 이름 검색용 화면
	 */
	public void selectByUserName() {
		
		System.out.println("--- 회원 이름 키워드 검색 ---");
		
		System.out.print("검색할 회원 이름 키워드 : ");
		String keyword = sc.nextLine();
		
		// Controller 의 어떤 메소드를 호출하면서 검색 요청
		// 검색어로 keyword 를 전달하면서!!
		mc.selectByUserName(keyword);
		
		
	}
	public void updateMember() {
		System.out.println("--- 회원 정보 변경 ---");
		
		// 무엇을 어떻게 바꿀건지?
		// userId 로 누구의 정보를 수정할건지 한놈만 골라내기
		// 비번, 이메일, 전화번호, 주소 변경해보기
		
		System.out.print("변경할 회원의 아이디 : ");
		String userId = sc.nextLine();
		
		System.out.print("* 변경할 비밀 번호 : ");
		String newPwd = sc.nextLine();
		
		System.out.print("변경할 이메일 : ");
		String newEmail = sc.nextLine();
		
		System.out.print("변경할 전화번호 (숫자만) : ");
		String newPhone = sc.nextLine();
		
		
		System.out.println("변경할 주소 : ");
		String newAddress = sc.nextLine();
		
		// Controller 의 어떤 메소드를 호출하면서 변경 요청
		mc.updateMember(userId, newPwd, newEmail,newPhone,newAddress);
		
		
	}
	public void deleteMember() {
		System.out.println("--- 회원 탈퇴 ---");
		
		// 삭제 또한 내가 원하는 행 하나만 정확하게 선택해야 함!!
		// > 탈퇴시킬 회원의 아이디로 입력받아, 일치하는 행만 찾아갈 것
		System.out.print("탈퇴할 회원의 아이디 : ");
		String userId = sc.nextLine();
		
		// Controller 의 어떤 메소드를 호출하면서 요청
		mc.deleteMember(userId);
	}
	
	//----------------------------------------------------
	// 응답 시 보여줄 화면들
	
	/**
	 * 요청 성공 시 보여질 화면
	 * @param message => 성공메시지 문구
	 */
	public void displaySuccess(String message) {
		
		System.out.println("서비스 요청 성공 : " + message);
		
		
	}
	
	/**
	 * 요청 실패 시 보여질 화면
	 * @param message => 실패메시지 문구
	 */
	public void displayFail(String message) {
		
		System.out.println("서비스 요청 실패 : " + message);
	}
	
	/**
	 * 조회 서비스 요청시 조회결과가 없을 경우 보여질 화면
	 * @param message => 메세지 내용
	 */
	public void displayNodata(String message) {
		System.out.println(message);
	}
	/**
	 * 조회 서비스 요청 시 여러 행이 조회된 결과를 받아서 보여줄 화면
	 * @param list => 여러 행이 조회된 결과
	 */
	public void dsiplayList(ArrayList<Member> list) {
		System.out.printf("조회된 데이터는 다음과 같습니다. (총 %d건)\n", list.size());
	
		for(int i=0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}
	
	}
	/**
	 * 조회 서비스 요청 시 단일행 조회 결과가 보여질 화면
	 * @param m => 조회된 한명의 회원의 정보
	 */
	public void displayOne(Member m) {
		
		System.out.println("조회된 데이터는 다음과 같습니다. (총1건)");
		System.out.println(m);
		
	}
	
	
	
	
}
