package com.kh.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.kh.model.vo.Member;



/*
 * * JDBC 용 객체
 * - Connection 
 * : DB 의 연결정보를 담고 있는 객체
 * 	 Connection 객체가 생성됨 과 동시에 DB 에 접속됨
 * - (Prepared)Statement 
 * : 해당 DB 에 SQL 문을 전달하고 실행한 후 결과를 받아내는 객체  
 * - ResultSet 
 * : 만일 실행한 SQL 문이 SELECT 문일 경우 조회된 결과들이
 * 	 담겨있는 객체 (돌아온다라고 생각하면됨)
 * 
 * * Statement (부모) 와 PreparedStatement (자식) 의 차이점
 * - Statement 같은 경우 완성된 SQL 문을 바로 실행하는 객체
 *   SQL 문이 완성된 형태로 반드시 셋팅되어있어야만 한다!!
 *   (즉, 사용자가 입력했던 값들이 문자열로 다 채워진 상태)
 *   
 *   > Connection 객체를 가지고 Statement 객체를 생성
 *     stmt = conn.createStatement(); // sql문 전달 X
 *   > executeXxxxx 메소드를 이용해서 SQL 문을 전달하면서 실행
 *     결과 = executeXxxx(sql); // sql 문 전달과 동시에 실행
 *   
 * - PreparedStatement 같은 경우 SQL 문을 바로 실행하지 않고
 *   잠시 보관을 해둘 수 있음
 * 	 미완성된 SQL 문을 잠시 보관해둘 수 있음
 *   단, 사용자가 입력한 값들이 들어갈 수 있는 공간을 미리 확보해야함
 *   쿼리문 중간에 나중에 데이터가 들어갈 "구멍" 을 뚫어주겠다!!
 *   구멍을 뚫을 때 ?(? : 위치 홀더) 로 뚫는다!!
 *   (즉, 해당 SQL 문을 실행하기 전에 완성 형태로 만든 후
 *    실행만 해주면 된다)
 * 	 
 * 	 > Connection 객체를 가지고 PreparedStatement 객체 생성
 *     pstmt = conn.prepareStatement(sql); // sql문 미리 넘기기
 *   > 현재 담겨있는 SQL 문이 "미완성된" 쿼리문일 경우
 *     빈 공간들을 실제 값으로 채워서 완성시키는 과정
 *     pstmt.setString(1, "실제값");
 *     pstmt.setInt(2, 실제값);
 *   > executeXxxxx 메소드를 이용해서 SQL 문을 실행
 * 	    결과 = pstmt.executeXxxxx(); // sql 문을 넘기지 않음
 *   
 * 
 * 
 * * JDBC 처리 순서
 * 1) JDBC Driver 등록
 * : 해당 DBMS 가 제공하는 클래스 등록
 * 2) Connection 객체 생성
 * : 접속하고자 하는 DB 정보를 입력해서 DB 에 접속하면서 생성
 * 3_1) PreparedStatement 객체 생성
 * : Connection 객체를 이용해서 생성 
 *   (이 때, SQL 문을 담은 채로 생성)
 * 3_2) 현재 미완성된 SQL문을 완성형태로 채워주는 과정
 * : 미완성된 경우에만 해당, 완성된 경우에는 과정 생략
 * 4) SQL 문 실행
 * : PreparedStatement 객체를 이용해서 SQL 문 실행  
 *  (sql 문 매개면수 없음)
 *  > SELECT 문의 경우 : executeQuery 메소드
 *  > INSERT, UPDATE, DELETE 문의 경우 : executeUpdate 메소드
 *  5) 결과 받기
 *    > SELECT 문의 경우 : ResultSet 객체에 조회 결과가 당겨옴
 *    > INSERT, UPDATE, DELETE 문의 경우 : int (처리된 행의 갯수)
 * 6_1) ResultSet 에 담겨있는 데이터들을 하나씩 뽑아서 VO 객체로 옮겨담기
 * 6_2) 트랜젝션 처리 (성공시 COMMIT, 실패시 ROLLBACK) 
 * 7) 다쓴 JDBC 용 자원 반드시 (finally) 반납
 * : 생성 순서의 역순으로 진행!!
 * 8) Controller 로 결과 반환
 *  > SELECT 문의 경우 6_1) 에서 만들어진 결과
 *  > INSERT, UPDATE, DELETE 문의 경우 : int (처리된 행의 갯수)
 *  
 *  
 *  
 */
public class MemberDao {

	/**
	 * MEMBER 테이블에 INSERT 작업을 해주는 메소드
	 * @param m => INSERT 할 회원의 정보
	 * @return => 추가된 행의 갯수
	 */
	public int insertMember(Member m) {
		
		// insert 문 => int (처리된 행의 갯수) => 트랜젝션 처리
		
		// 0) 필요하 변수들 먼저 셋팅
		int result= 0; // 처리된 행의 갯수를 담아줄 변수
		Connection conn = null;
			// 접속할 DB의 연결정보를 담는 변수
		PreparedStatement pstmt = null;
			// SQL 문 실행 후 결과를 받기 위한 변수
		
		
		// 실행할 SQL 문 (미완성된 형태로 , 세미콜론 X)
		String sql = "INSERT INTO MEMBER VALUES(SEQ_USERNO.NEXTVAL"
				+ ", ?"
				+ ", ?"
				+ ", ?"
				+ ", ?"
				+ ", ?"
				+ ", ?"
				+ ", ?"
				+ ", ?"
				+ ", ?"
				+ ", SYSDATE)";
		
		// 1) JDBC Driver 등록
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
		// 2) Connection 객체 생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			
		// 3_1) SQL문을 넘기면서 PreparedStatement 객체 생성
			pstmt = conn.prepareStatement(sql);
			
		// 3_2) 미완성된 SQL 문일 경우에 값 채워주기
		// [ 표현법 ]
		// pstmt.setXxx(홀더 순번, 대체할값);
		// > pstmt.setInt(홀더 순번, 대체할값); => 대체할값
		// > pstmt.setString(홀더 순번, "대체할값"); => '대체할값'
		//   setString 메소드 만큼은 대체할값으로 쿼리문이 완성될때
		//   문자열 값의 양 사이드에 홑따옴표 ('') 가 붙여져서 들어가게됨!!
		pstmt.setString(1, m.getUserId());
		pstmt.setString(2, m.getUserPwd());
		pstmt.setString(3, m.getUserName());
		pstmt.setString(4, m.getGender());
		pstmt.setInt(5, m.getAge());
		pstmt.setString(6, m.getEmail());
		pstmt.setString(7, m.getPhone());
		pstmt.setString(8, m.getAddress());
		pstmt.setString(9, m.getHobby());
		
		// PreparedStatement 의 최대 단점
		// > 완성된 SQL 문의 형태를 확인할 수 없다!!
		
		// 4, 5) SQL 문 실행 후 결과 받기
		// - 실행할 구문 종류 : insert
		// - 실행할 메소드명 : executeUpdate
		result = pstmt.executeUpdate();
		
		// 6_2) 트랜잭션 처리
		if(result > 0) { // 성공 (commit)
			
			conn.commit();
			
			
		}else { // 실패 (rollback)
			
			conn.rollback();
			
		}
		
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			// 7) 다쓴 JDBC 자원 반납하기 (역순)
			
			try {
				
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		// 8) Controller 로 리턴
		return result; // 처리된 행의 갯수
	} // insertMember 메소드 끝
	
	/**
	 * MEMBER 테이블에 전체 조회용 SELECT 문을 실행하는 메소드
	 * @return => 조회된 회원들의 정보
	 */
	public ArrayList<Member> selectAll(){
		// select 문 => ResultSet 객체
		// => ArrayList<Member>
		
		// 0) 필요한 변수들 먼저 셋팅
		ArrayList<Member> list = new ArrayList<>();
			// 조회된 결과를 뽑아서 담아줄 ArrayList (텅 빈 리스트)
		Connection conn = null;
			// 접속할 DB의 연결정보를 담을 변수
		PreparedStatement pstmt = null;
			// SQL 문 실행 후 결과를 받기  위한 변수
		ResultSet rset = null;
			// select 문이 실행된 조회결과들이 담겨서 돌아오는 객체
		
		
		// 실행할 SQL 문 (미완성되든 완성되든 사실 상관없음, 세미콜론 X)
		// > 완성된 쿼리문 또한 PreparedStatement 사용 가능!!
		String sql = "SELECT * "
				+ "FROM MEMBER"; // 완성된 형태
		

		try {
			// 1) JDBC Driver 등록
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// 2) Connection 객체 생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			
			// 3_1) SQL 문을 넘기면서 PreparedStatement 객체 생성
			pstmt = conn.prepareStatement(sql); // sql 넘김
			
			
			// 3_2) 미완성된 SQL 구문일 경우 완성시키기
			// > 완성된 SQL 문이므로 패스
			
			// 4, 5) SQL 문 실행 후 결과 받기
			// - 실행할 쿼리문 종류 : select 문
			// - 호출할 메소드명 : executeQuery
			rset = pstmt.executeQuery(); // sql문 X
			
			// 6_1) ResultSet 에 담긴 조회 결과를
			//      VO 객체로 옮겨담기
			// > 여러행 조회 : 반복 횟수를 모르므로 while(rset.next());
			while(rset.next()) {
				
				// 이 중괄호 안족으로 흐름이 들어왔다라는 것은
				// 현재 커서가 가리키는 곳에 뽑을 데이터가 있다라는것!!
				// 한 행 --> 한개의 VO 단위로 옮기기 --> list 에 add
				
				Member m = new Member();
				// rset 으로부터 어떤 컬럼에 해당하는 값을 뽑을건지
				// 컬럼명을 대문자로 제시!!
				
				m.setUserNo(rset.getInt("USERNO"));
				m.setUserId(rset.getString("USERID"));
				m.setUserPwd(rset.getString("USERPWD"));
				m.setUserName(rset.getString("USERNAME"));
				m.setGender(rset.getString("GENDER"));
				m.setAge(rset.getInt("AGE"));
				m.setEmail(rset.getString("EMAIL"));
				m.setPhone(rset.getString("PHONE"));
				m.setAddress(rset.getString("ADDRESS"));
				m.setHobby(rset.getString("HOBBY"));
				m.setEnrollDate(rset.getDate("ENROLLDATE"));
			// 리스트에 해당 Member 객체를 담아두기
				list.add(m);
				
				
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				rset.close();
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
					}
		
		//8) Controller 로 리턴
		return list;
		
		
	} // selectAll 메소드 끝
	
	/**
	 * MEMBER 테이블에 아이디로 조회해주는 SELECT 문을 설명해주는 메소드
	 * @param userId => 검색할 회원의 아이디
	 * @return => 조회된 회원 한명의 정보
	 */
	public Member selectByUserId(String userId) {
		// select 문 => ResultSet 객체 (단일행 조회)
		// => Member 
		// 0) 필요한 변수들 먼저 셋팅
		Member m = null;
		// 조회된 한명의 회원의 정보를담을변수
		Connection conn = null;
		// 접속할 DB의 정보를 담을 변수
		PreparedStatement pstmt = null;
		// SQL 문 실행후 결과를 받기위한 변수
		ResultSet rset = null;
		// select 문이 실행 후 결과가 담겨올 변수
		
		String sql = "SELECT * FROM MEMBER WHERE USERID = ?";
		// 실행할 SQL 문
		try {
			// 1) JDBC Driver 등록
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2) Connection 객체 생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			// 3_1) SQL 문을 넘기면서 PreparedStatement 객체 생성
			pstmt = conn.prepareStatement(sql);
			// 3_2) 미완성된 SQL 문을 완성시키기
			pstmt.setString(1, userId);
			// 4,5) SQL 문이 실행 후 결과 받기
			// - 실행할 쿼리문 종류 : select 문
			// - 호출할 메소드 명 : executeQuery
						
			rset = pstmt.executeQuery(); // sql 매개면수 X
			
			// 6_1) ResultSet 의 조회된 결과를 VO 로 옮겨담기
			// > 단일행 조회이므로 커서는 한번만 옮겨도 충분하니깐
			//   if(rset.next())
			
			
			if(rset.next()) {
				// 조회된 데이터가 있을 경우
				// 한 행 데이터 --> Member 객체 한개로 옮기기
				
				m = new Member(rset.getInt("USERNO"),
						   rset.getString("USERID"),
						   rset.getString("USERPWD"),
						   rset.getString("USERNAME"),
						   rset.getString("GENDER"),
						   rset.getInt("AGE"),
						   rset.getString("EMAIL"),
						   rset.getString("PHONE"),
						   rset.getString("ADDRESS"),
						   rset.getString("HOBBY"),
						   rset.getDate("ENROLLDATE"));
			}
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rset.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// 8) Controller 로 결과 리턴
		return m;
	} // selectByUserId 메소드 끝
	
	/**
	 * 테이블에 이름 키워드 검색용 SELECT 문을 실행해주는 메소드
	 * @param keyword => 이름 키워드 검색용 검색어
	 * @return => 조회된 회원들의 정보
	 */
	public ArrayList<Member> selectByUserName(String keyword){
		// select 문 => ResultSet 객체 (여러행 조회)
		// => ArrayList<Member>
		
		// 0) 필요한 변수들 먼저 셋팅
		ArrayList<Member> list
		=new ArrayList<>();
		// 조회된 회원들의 정보를 담을 리스트 (텅빈 리스트)
		Connection conn = null;
		// 접속할 DB 의 정보를 담아줄 변수
		PreparedStatement pstmt = null;
		// SQL 문 실행 후 결과를 받아낼 변수
		ResultSet rset = null;
		// select 문의 실행 결과가 담겨서 돌아올 변수
		
		
		// 실행할 SQL 문 (미완성된 형태로 , 세미콜론 X)
		/*
		 주의할 점)
		 경우1)
		 
		  
		SELECT * FROM MEMBER
		WHERE USERNAME LIKE '%?%'
		
		
		> pstmt.setString(1, keyword); 으로 완성시킨다면
		'%'xxx'%' 로 구멍이 메꿔지게 됨!! (문법 오류)
		
		
		경우2) 해결방법
		  
		SELECT * FROM MEMBER
		WHERE USERNAME LIKE '%'||?||'%' >> 오라클에서는 이어주는 문법이다
		'%' || 'xxx' || '%' 로 구멍이 메꿔지게 됨!! (오류 X)
		
		경우3) 해결방법2
		
		  
		SELECT * FROM MEMBER
		WHERE USERNAME LIKE ? 
		
		> pstmt.setString(1, "%" + keyword + "%"); 으로 완성시킨다면
		'%xxx%' 로 구멍이 메꿔지게 됨!! (오류x)
		
		*/
		String sql = "SELECT * "
				+ "FROM MEMBER "
				+ "WHERE USERNAME LIKE ?";
		
		
		try {
			//1) JDBC Driver 등록
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//2) Connection 객체 생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			
			// 3-1) SQL 문을 넘기면서 PreparedStatement 객체 생성
			pstmt = conn.prepareStatement(sql);
			// 3_2_ 미완성된 SQL 문 완성 시키기
			pstmt.setString(1, "%" + keyword +"%");
			
			//4 ,5 ) SQL 문 실행 후 결과 받기
			// - 실행할 쿼리문 종류 : select 문
			// - 호출할 메소드 명 : executeQuery
			rset = pstmt.executeQuery();
			//6_1) ResultSet 조회된 데이터들을 VO로 옮기기
			// > 여러행 조회이므로 반복적으로 실행되게 while(rest.next())
			while(rset.next()) {
				
				// 한 행의 데이터 --> Member객체 한개 --> list 에 add
				
				list.add(new Member(rset.getInt("USERNO"),
									rset.getString("USERID"),
									rset.getString("USERPWD"),
									rset.getString("USERNAME"),
									rset.getString("GENDER"),
									rset.getInt("AGE"),
									rset.getString("EMAIL"),
									rset.getString("PHONE"),
									rset.getString("ADDRESS"),
									rset.getString("HOBBY"),
									rset.getDate("ENROLLDATE")));	
				
				
				
			}
		}catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			 catch (SQLException e) {
			e.printStackTrace();
			 }finally {
			//8) 다쓴 JDBC 자원 반납하기 (역순)
			try {
				rset.close();
				pstmt.close();
				conn.close();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		// 9) 값 반환해주기
		return list;
		}
	
		/**
		 * MEMBER 테이블에 UPDATE 구문을 실행해주는 메소드
		 * @param m => 변경할 회원에 대한 정보들
		 * @return => 수정된 행의 갯수
		 */
		public int updateMember(Member m) {
			// update 문 => int(처리된 행의 갯수) => 트랜잭션 처리
			
			//0) 필요한 변수들 먼저 셋팅
			int result = 0; //처리된 행의 갯수를 담아둘 변수
			Connection conn = null;
				// 접속할 DB 에 대한 정보를 담을 변수
			PreparedStatement pstmt = null;
			    // SQL 문 실행 후 결과를 받아낼 변수
			
			// 실행할 SQL 문 (미완성된 형태로, 세미콜론 X)
			
			/*
			UPDATE MEMBER
				   SET USERPWD = ?
					 , EMAIL = ?
					 , PHONE = ?
					 , ADDRESS = ?
					 , WHERE USERID = ?
			*/
			
			String sql = "UPDATE MEMBER "
					+ "SET USERPWD = ?"
					+ ", EMAIL = ?"
					+ ", PHONE = ?"
					+ ", ADDRESS = ? "
					+ "WHERE USERID = ?";
			
			
			
			try {
				// 1) JDBC Driver 등록
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				// 2) Connection 객체 생성
				conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
				
				//3_1) SQL 문을 전달하면서 PreparedStatement 객체 생성
				pstmt = conn.prepareStatement(sql);
				
				//3_2) 미완성된 SQL 문 완성 시키기
				
				pstmt.setString(1, m.getUserPwd());
				pstmt.setString(2, m.getEmail());
				pstmt.setString(3, m.getPhone());
				pstmt.setString(4, m.getAddress());
				
				// 4, 5) SQL 문 실행 후 결과 받기
				// - 실행할 쿼리문 종류 : update 문
				// - 호출할 메소드명 : executeUpdate
				result = pstmt.executeUpdate();
				
				//6_2) 트랜젝션 처리
				if(result > 0) { // 성공 (commit)
					conn.commit();
				}else { // 실패 (rollback)
					conn.rollback();
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				
				try {
					//7) 다쓴 JDBC 자원 반납
					pstmt.close();
					conn.close();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			
			// 8) Controller 로 반납
			return result;
		} //  updateMember 메소드 끝
		
		/**
		 * MEMBER 테이블에 DELETE 구문을 실행시켜줄 메소드
		 * @param userId => 탈퇴 (삭제) 시킬 회원의 아이디
		 * @return => 삭제된 행의 갯수
		 */
		public int deleteMember(String userId) {
			// delete 문 => int (처리된 행의 갯수) => 트랜잭션 처리
			
			// 0) 필요한 변수들 먼저 셋팅
			int result =0; //처리된 행의 갯수를 담을 변수
			Connection conn = null;
			// 접속할 DB 의 정보를 담을 변수
			
			PreparedStatement pstmt = null;
			 // SQL 문 실행 후 결과를 받아낼 변수
			
			// 실행할 SQL 문 (미완성 형태로 , 세미콜론 X)
			String sql = "DELETE "
					+ "FROM MEMBER "
					+ "WHERE USERID = ?";
			
			// 1) JDBC Driver 등록
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				// 2) Connection 객체 생성
				conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
				
				// 3_1) SQL 문을 전달하면서 PreparedStatement 객체 생성
				pstmt = conn.prepareStatement(sql);
				
				// 3_2) 미완성된 SQL 문 완성 시키기
				pstmt.setString(1, userId);
				
				// 4, 5) SQL 문 실행 후 결과 받기
				// - 실행할 쿼리문 종류 : delete 문
				// - 호출할 메소드 명 : executeUpdate
				result = pstmt.executeUpdate();
				
				// 6_2) 트랜잭션 처리
				if(result > 0) { // 성공(commit)
					conn.commit();
				}else { // 실패 (rollback)
					conn.rollback();
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				try {
					// 7) 다쓴 JDBC 역순으로 자원 반납하기
					
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			//8) Controller 로 결과 반환
			return result;
		} //deleteMember 메소드 끝
	
	
	
}
